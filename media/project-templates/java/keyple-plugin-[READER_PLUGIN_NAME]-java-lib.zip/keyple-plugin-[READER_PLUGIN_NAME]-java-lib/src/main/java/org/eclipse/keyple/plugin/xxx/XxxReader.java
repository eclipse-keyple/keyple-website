package org.eclipse.keyple.plugin.xxx;

import org.eclipse.keyple.core.common.KeypleReaderExtension;

/**
 * TODO
 *
 * @since TODO
 */
public interface XxxReader extends KeypleReaderExtension {}
