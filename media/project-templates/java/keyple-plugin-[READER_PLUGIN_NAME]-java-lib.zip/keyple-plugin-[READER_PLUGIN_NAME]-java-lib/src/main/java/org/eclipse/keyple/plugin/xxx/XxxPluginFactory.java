package org.eclipse.keyple.plugin.xxx;

import org.eclipse.keyple.core.common.KeyplePluginExtensionFactory;

/**
 * TODO
 *
 * @since TODO
 */
public interface XxxPluginFactory extends KeyplePluginExtensionFactory {}
