rootProject.name = "keyple-plugin-[READER_PLUGIN_NAME]-java-lib"
