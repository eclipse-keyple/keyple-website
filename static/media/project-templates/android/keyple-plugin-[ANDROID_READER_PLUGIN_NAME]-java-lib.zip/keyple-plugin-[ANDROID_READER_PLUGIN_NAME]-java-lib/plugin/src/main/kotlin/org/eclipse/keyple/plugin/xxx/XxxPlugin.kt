package org.eclipse.keyple.plugin.xxx

import org.eclipse.keyple.core.common.KeyplePluginExtension

/**
 * TODO
 *
 * @since TODO
 */
interface XxxPlugin : KeyplePluginExtension