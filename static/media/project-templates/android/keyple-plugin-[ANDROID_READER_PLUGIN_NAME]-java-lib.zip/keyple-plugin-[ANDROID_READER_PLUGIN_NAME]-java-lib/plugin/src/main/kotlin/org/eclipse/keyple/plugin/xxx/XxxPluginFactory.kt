package org.eclipse.keyple.plugin.xxx

import org.eclipse.keyple.core.common.KeyplePluginExtensionFactory

/**
 * TODO
 *
 * @since TODO
 */
interface XxxPluginFactory : KeyplePluginExtensionFactory