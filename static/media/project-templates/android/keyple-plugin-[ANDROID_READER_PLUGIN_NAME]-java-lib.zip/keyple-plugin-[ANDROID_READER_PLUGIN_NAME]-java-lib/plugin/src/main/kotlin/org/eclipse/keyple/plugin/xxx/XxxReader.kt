package org.eclipse.keyple.plugin.xxx

import org.eclipse.keyple.core.common.KeypleReaderExtension

/**
 * TODO
 *
 * @since TODO
 */
interface XxxReader : KeypleReaderExtension