include(":plugin")
rootProject.name = "keyple-plugin-[ANDROID_READER_PLUGIN_NAME]-java-lib"
