package org.eclipse.keyple.card.xxx;

import org.eclipse.keyple.core.common.KeyplePluginExtension;

/**
 * TODO
 *
 * @since TODO
 */
public interface XxxCardSelection extends KeyplePluginExtension {}
