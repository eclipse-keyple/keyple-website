package org.eclipse.keyple.card.xxx;

import org.calypsonet.terminal.reader.selection.spi.SmartCard;

/**
 * TODO
 *
 * @since TODO
 */
public interface XxxSmartCard extends SmartCard {}
