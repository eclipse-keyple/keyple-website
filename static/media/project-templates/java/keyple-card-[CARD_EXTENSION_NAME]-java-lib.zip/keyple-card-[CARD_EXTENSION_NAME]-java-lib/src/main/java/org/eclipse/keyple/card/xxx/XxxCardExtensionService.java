package org.eclipse.keyple.card.xxx;

import org.eclipse.keyple.core.common.KeypleCardExtension;

/**
 * TODO
 *
 * @since TODO
 */
public final class XxxCardExtensionService implements KeypleCardExtension {}
