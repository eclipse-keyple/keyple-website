rootProject.name = "keyple-card-[CARD_EXTENSION_NAME]-java-lib"
